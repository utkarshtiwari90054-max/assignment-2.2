# Assignment 2.2 — Personal Introduction Page

## Description
A resume-style webpage that introduces me, with About Me, Education, Skills and Hobbies sections.

## HTML Elements Used
- Headings `h1` to `h6` (name, section titles, sub-sections)
- `p` for paragraphs, `br` for line breaks, `hr` for separators
- `strong`, `em` and `i` for important or emphasised text
- `div` to group related sections, `span` for inline content

## Project Structure
```
assignment-2.2/
├── index.html
├── screenshot.png
└── README.md
```

## How to Run
Open `index.html` in any web browser.

## Screenshot
![Browser output](screenshot.png)
